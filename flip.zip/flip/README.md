# cardflip
simple card flip animation using jQuery and CSS3 animations

do whatever you wish with this

clone the repos and run bower install to grab dependencies

add some images and you're good to go

here is a demo: [cardflip](http://cardflip.apphb.com/)
